<!-- resources/views/emails/welcome.blade.php -->
<h1>Welcome, {{ $user->name }}!</h1>
<p>Thank you for registering with us. We’re thrilled to have you on board!</p>
