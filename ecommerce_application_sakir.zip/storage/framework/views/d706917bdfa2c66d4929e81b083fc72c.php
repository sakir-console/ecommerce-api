<!-- resources/views/emails/welcome.blade.php -->
<h1>Welcome, <?php echo e($user->name); ?>!</h1>
<p>Thank you for registering with us. We’re thrilled to have you on board!</p>
<?php /**PATH C:\Users\sakir\OneDrive\Desktop\getup\ecommerce_application_sakir\resources\views/emails/welcome.blade.php ENDPATH**/ ?>